-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Dec 15, 2015 at 01:12 PM
-- Server version: 5.0.41
-- PHP Version: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `test`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `members`
-- 

CREATE TABLE `members` (
  `user_id` int(11) NOT NULL auto_increment,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY  (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `members`
-- 

INSERT INTO `members` (`user_id`, `user_name`, `password`) VALUES 
(2, 'admin', 'admin'),
(3, 'mwenge', '1234');

-- --------------------------------------------------------

-- 
-- Table structure for table `tikect`
-- 

CREATE TABLE `tikect` (
  `id` int(11) NOT NULL auto_increment,
  `bus_num` varchar(15) NOT NULL,
  `day` int(2) NOT NULL,
  `month` varchar(15) NOT NULL,
  `type` varchar(15) NOT NULL,
  `board` varchar(100) NOT NULL,
  `too` varchar(55) NOT NULL,
  `root` varchar(20) NOT NULL,
  `mobile` int(13) NOT NULL,
  `name` varchar(255) NOT NULL,
  `age` varchar(15) NOT NULL,
  `adress` varchar(55) NOT NULL,
  `nationality` varchar(55) NOT NULL,
  `passport` varchar(55) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `berth` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `tikect`
-- 

INSERT INTO `tikect` (`id`, `bus_num`, `day`, `month`, `type`, `board`, `too`, `root`, `mobile`, `name`, `age`, `adress`, `nationality`, `passport`, `gender`, `berth`) VALUES 
(1, 'eefcefaq', 1, 'January', 'Sleeper', 'fef', 'srg', 'Root 1', 11, 'efe', '22', 'srg', 'rwsfd', '', '', ''),
(2, 'bvg', 1, 'January', 'Sleeper', 'bhybh', 'hbhyb', 'Root 1', 11, 'hbheb', '11', 'behbh', 'hbhefb', '2gy2', 'Male', ''),
(3, 'sdv', 1, 'January', 'Sleeper', 'efe', 'wef', 'Root 1', 111, 'sgv', '33', 'srrf', 'sgd', 'rg4', 'Male', ''),
(4, 'bs21', 6, 'April', 'Semi Sleeper', 'kampal', 'nakawa', 'Root 2', 77777, 'said', '12', 'kololo', 'uganda', 'nw12hdd', 'Male', 'Window');
